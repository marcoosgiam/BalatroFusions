SMODS.Joker{ --Oops! All 0s
    key = "oopsall0s",
    config = {
        extra = {
            mod_probability = 0,
            numerator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Oops! All 0s',
        ['text'] = {
            [1] = 'Makes all {C:attention}listed{} {C:green}probabilities{} to 0',
            [2] = '(ex: {C:green}1 in 3{} -> {C:green}0 in 3{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
          if context.mod_probability and not context.blueprint then
          local numerator, denominator = context.numerator, context.denominator
                  numerator = numerator * card.ability.extra.mod_probability
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
    end
}