SMODS.Consumable {
    key = 'testfusion',
    set = 'Tarot',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = 'Test Fusion',
        text = {
        [1] = 'A test fusion card'
    }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local input = G.jokers.highlighted
        local result = SMODS.BalatroFusions.Fusion:get(G.jokers.highlighted)
        SMODS.BalatroFusions.Fusion:fuse(result,input)
    end,
    can_use = function(self, card)
        return #G.jokers.highlighted == 2 and SMODS.BalatroFusions.Fusion:get(G.jokers.highlighted) ~= nil
    end
}